# WebRTC DFD Model for Threat Modelling

## Files and explanation

### Model files

* representations.aird  
  Graphical model of the WebRTC model
* WebRTC.sparta  
  Concrete webrtc model

### Threat modelling artefacts

* SecurityPatternCatalog.sparta  
  Catalog with security pattern solutions, which can be instantiated in the model.
* LINDDUN-PRO.sparta
  LINDDUN-per-interaction threat table



