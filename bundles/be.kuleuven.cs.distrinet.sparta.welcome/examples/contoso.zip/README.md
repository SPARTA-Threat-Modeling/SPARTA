# Contoso DFD Model for Threat Modelling

## Files and explanation

### Model files

* representations.aird
  Graphical representation of the Contoso model
* Contoso.sparta
  Concrete contoso model

### Threat modelling artefacts

* SecurityPatternCatalog.sparta
  Catalog with security pattern solutions, which can be instantiated in the model.
* stride-per-interaction - Shostack.sparta
  Stride threat mapping table from Shostack 2014.
