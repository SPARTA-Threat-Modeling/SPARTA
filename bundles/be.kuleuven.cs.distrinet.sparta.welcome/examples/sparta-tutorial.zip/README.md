# SPARTA guided tutorial

Starter project for the *Create and analyze your first model* cheat sheet
(Help > Cheat Sheets... > SPARTA, or the guided tutorial on the welcome screen).

* stride-per-interaction - Shostack.sparta
  Threat type catalog implementing STRIDE-per-interaction (Shostack 2014).
* SecurityPatternCatalog.sparta
  Catalog with security pattern solutions, which can be instantiated in the model.

Your own DFD model (.sparta) and its diagram are added to this project as you follow the tutorial.
More catalogs: https://github.com/SPARTA-Threat-Modeling/catalogs
